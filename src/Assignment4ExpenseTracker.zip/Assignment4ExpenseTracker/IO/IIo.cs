﻿namespace Assignment4ExpenseTracker.IO
{
    internal class IIo
    {
    }
}
