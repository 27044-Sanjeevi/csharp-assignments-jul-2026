﻿namespace Assignment4ExpenseTracker.IO
{
    internal class ConsoleIO
    {
    }
}
