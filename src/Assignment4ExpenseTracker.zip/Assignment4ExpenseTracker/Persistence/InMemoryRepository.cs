﻿namespace Assignment4ExpenseTracker.Persistence
{
    internal class InMemoryRepository
    {
        
    }
}
