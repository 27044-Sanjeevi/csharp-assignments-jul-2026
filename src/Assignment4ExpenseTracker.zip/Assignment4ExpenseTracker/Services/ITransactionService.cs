﻿namespace Assignment4ExpenseTracker.Services
{
    internal class ITransactionService
    {
    }
}
