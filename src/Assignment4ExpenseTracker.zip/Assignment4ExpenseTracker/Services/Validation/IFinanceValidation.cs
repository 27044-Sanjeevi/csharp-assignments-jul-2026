﻿namespace Assignment4ExpenseTracker.Services.Validation
{
    internal class IFinanceValidation
    {
    }
}
