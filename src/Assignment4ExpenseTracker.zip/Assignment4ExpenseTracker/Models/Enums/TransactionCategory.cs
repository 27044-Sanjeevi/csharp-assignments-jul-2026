﻿namespace Assignment4ExpenseTracker.Models.Enums
{
    /// <summary>
    /// Specifies the category of transaction including income and expense.
    /// </summary>
    internal enum TransactionCategory
    {
        // Income Sources

        /// <summary>
        /// Sepcifies the income through salary.
        /// </summary>
        Salary = 1,

        /// <summary>
        /// Specifies the income through Investments.
        /// </summary>
        Investment = 2,

        /// <summary>
        /// Specifies the expense for transportation.
        /// </summary>
        Transport = 3,

        /// <summary>
        /// Specifies the expense for Utilities.
        /// </summary>
        Utilities = 4,

        /// <summary>
        /// Specifies the expense for Groceries.
        /// </summary>
        Groceries = 5,

        /// <summary>
        /// Specifies the expense for Rent.
        /// </summary>
        Rent = 6,

        /// <summary>
        /// Specifies the expense for Food.
        /// </summary>
        Food = 7,

        /// <summary>
        /// Specifies the expense for Shopping.
        /// </summary>
        Shopping = 8,

        /// <summary>
        /// Specifies any Miscellaneous expense.
        /// </summary>
        Miscellaneous = 9,
    }
}
