﻿namespace Assignment4ExpenseTracker.View
{
    internal class IView
    {
    }
}
