﻿namespace Assignment4ExpenseTracker.Controller
{
    internal class FinanceController
    {
    }
}
